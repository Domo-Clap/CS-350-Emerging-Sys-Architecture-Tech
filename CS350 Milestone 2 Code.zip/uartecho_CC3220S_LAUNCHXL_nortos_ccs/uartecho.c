/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== uartecho.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>

/* Driver configuration */
#include "ti_drivers_config.h"



//State Machine
enum States {LED_Start, LED_on, LED_off, LED_O, LED_F} LED_State; //Creates the states that will be used to control the LED

//Basic Tick function that will control how the States change and the state actions. Takes in one character of input at a time. So, you enter 'O' first, then 'N'
void Tick_func(char input) {

    //Start of the transition switch. Used to transition between states
    switch(LED_State){

        //This is essentially our initial state that acts as the start of the system
        case LED_Start:

            //If the first character input equals 'O' or 'o', then the state will transition to the O state
            if (input == 'O' || input == 'o') {
                LED_State = LED_O;
            }
            //Otherwise, the state will stay on the LED_Start state
            else {
                LED_State = LED_Start;
            }

            break;

        //This state represents the state wherein the first input was an 'O' or 'o'
        case LED_O:
            //If the second character input equals 'n' or 'N', then the state will transition to the LED_on state
            if (input == 'n' || input == 'N') {
                LED_State = LED_on;
            }
            //If the second character input equals 'f' or 'F', then the state will transition to the F state
            else if (input == 'f' || input == 'F') {
                LED_State = LED_F;
            }
            //Otherwise, the state will fall back to the LED_Start state
            else {
                LED_State = LED_Start;
            }
            break;

        //This state represents the state wherein the second input was an 'F' or 'f'
        case LED_F:
            //If the third character input equals 'f' or 'F', then the state will transition to the LED_off state
            if (input == 'f' || input == 'F') {
                LED_State = LED_off;
            }
            //Otherwise, the state will fall back to the LED_Start state
            else {
                LED_State = LED_Start;
            }
            break;

        //Default state if needed
        default:
            LED_State = LED_Start;
            break;
    }

    //Start of the state action switch
    switch(LED_State){

        //If the state is still LED_Start from above, then the switch breaks and the loop starts again
        case LED_Start:
            break;

        //If the state is still O from above, then the switch breaks and the loop starts again
        case LED_O:
            break;

        //If the state is still F from above, then the switch breaks and the loop starts again
        case LED_F:
            break;

        //This state is reached when the user types in the characters O and N one after the other. This state is only reachable from the O State
        case LED_on:

            //Turns on the LED in the bottom right of the board
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            //Resets the LED_State and then reloops
            LED_State = LED_Start;
            break;

        //This state is reached when the user types in the characters O, F, and F one after the other. This state is only reachable from the F State
        case LED_off:

            //Turns off the LED in the bottom right of the board
            GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            //Resets the LED_State and then reloops
            LED_State = LED_Start;
            break;
    }

}


/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    char        input;
    const char  echoPrompt[] = "Echoing characters:\r\n";
    UART_Handle uart;
    UART_Params uartParams;

    /* Call driver init functions */
    GPIO_init();
    UART_init();

    /* Configure the LED pin */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Create a UART with data processing off. */
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }

    /* Turn on user LED to indicate successful initialization */
    //GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    UART_write(uart, echoPrompt, sizeof(echoPrompt));

    /* Loop forever echoing */
    while (1) {
        UART_read(uart, &input, 1);
        //Function call to the Tick Function made above
        Tick_func(input);
        UART_write(uart, &input, 1);
    }
}
