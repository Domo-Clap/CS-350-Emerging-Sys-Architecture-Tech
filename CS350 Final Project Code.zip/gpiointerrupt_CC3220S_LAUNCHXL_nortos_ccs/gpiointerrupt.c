/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

//Used to allow the bool variable to work properly
#include <stdbool.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/I2C.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

//UART define statement
#define DISPLAY(x) UART_write(uart, &output, x);

//UART global variables + handler
char output[64];
int bytesToSend;

//UART handler
UART_Handle uart;

void initUART(void)
{
    UART_Params uartParams;

    // Init the driver
    UART_init();

    // Configure the driver
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    // Open the driver
    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }
}

//Task structure to be used in the task scheduler
typedef struct task {
    int state; //The current state of the task
    unsigned long period; //The period for the task
    unsigned long elapsedTime; //The time passed since the last tick for the task
    int (*TickFct)(int); //The tick function to be used for the task

} task;

//An array of tasks for the task scheduler to loop over. 2 tasks total. 1 for the button check and 1 for the Temp-LED change
task tasks[2];

//Used in the timer loop later on as a comparison variable. Represents number of tasks in the tasks array
const unsigned char tasksNum = 2;

//Base period for the timer. It is set to 100 ms
const unsigned int timerPeriod = 100;
//This long variable represents the time in which the buttons will be checked. It is set to 200 ms
const unsigned long btnCheckTimer = 200;
//This long variable represents the time in which the temp is read and the LED is updated. It is set to 500 ms
const unsigned long led_tempCheckTimer = 500;
//Used to measure how often the output should be displayed in the terminal
unsigned long outputCheckTimer = 1000;

//This variable is used to track button 0 on the TI board. It is used later in the code to determine if the button 0 has been pressed. 0 is its base value, which means false.
unsigned char button_0 = 0;
//This variable is used to track button 1 on the TI board. It is used later in the code to determine if the button 1 has been pressed. 0 is its base value, which means false.
unsigned char button_1 = 0;

int16_t temperature; //Holds the value of the temperature found by the board
int setpoint; //Holds the setpoint temperature value that is compared with the temperature variable each second
int heat = 0; //Holds the heat value to determine if the heat will turn on or off
unsigned long seconds = 0; //Holds the time value in the form of seconds that is used to display the time in the terminal

//I2C Global Variables
static const struct {
    uint8_t address;
    uint8_t resultReg;
    char *id;
}
sensors[3] = {
              { 0x48, 0x0000, "11X" },
              { 0x49, 0x0000, "116" },
              { 0x41, 0x0001, "006" }
};

uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

//Driver Handles - Global variables
I2C_Handle i2c;

//Make sure you call initUART() before calling this function.
void initI2C(void)
{
    int8_t i, found;
    I2C_Params i2cParams;
    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "))

    //Init the driver
    I2C_init();

    //Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    //Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL) {
        DISPLAY(snprintf(output, 64, "Failed\n\r"))
        while (1);
    }
    DISPLAY(snprintf(output, 32, "Passed\n\r"))

    //Boards were shipped with different sensors.
    //Welcome to the world of embedded systems.
    //Try to determine which sensor we have.
    //Scan through the possible sensor addresses
    /*Common I2C transaction setup */
    i2cTransaction.writeBuf = txBuffer;
    i2cTransaction.writeCount = 1;
    i2cTransaction.readBuf = rxBuffer;
    i2cTransaction.readCount = 0;
    found = false;
    for (i=0; i<3; ++i) {
        i2cTransaction.slaveAddress = sensors[i].address;
        txBuffer[0] = sensors[i].resultReg;
        DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id))

        if (I2C_transfer(i2c, &i2cTransaction)) {
            DISPLAY(snprintf(output, 64, "Found\n\r"))
        found = true;
            break;
        }

        DISPLAY(snprintf(output, 64, "No\n\r"))
    }

    if(found) {
        DISPLAY(snprintf(output, 64, "Detected TMP%s I2C address: %x\n\r", sensors[i].id, i2cTransaction.slaveAddress))
    }
    else {
        DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"))
    }
}

int16_t readTemp(void) {
    int j;
    int16_t temperature = 0;
    i2cTransaction.readCount = 2;

    if (I2C_transfer(i2c, &i2cTransaction)) {
        /*
         * Extract degrees C from the received data;
         * see TMP sensor datasheet
         */
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;

        /*
         * If the MSB is set '1', then we have a 2's complement
         * negative value which needs to be sign extended
         */
        if (rxBuffer[0] & 0x80) {
            temperature |= 0xF000;
        }
    }
    else {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r",i2cTransaction.status))
        DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"))
    }
    return temperature;
}

Timer_Handle timer0;

volatile unsigned char TimerFlag = 0;

//Basic Timer callback function used for the Timer
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    unsigned char i; //Used in the comparison between the number of tasks in the tasks scheduler. Basic iterator variable

    //This for loop will run until i is greater than the number of tasks in the tasks array, aka, tasksNum
    for (i = 0; i < tasksNum; ++i) {
        //If the current tasks elapsed time is greater than or equal to the current tasks period, this branch will run
        if ( tasks[i].elapsedTime >= tasks[i].period ) {
            //The current tasks state is set to the current task's tick function state
            tasks[i].state = tasks[i].TickFct(tasks[i].state);
            //The current task then has its elapsed time reset to 0
            tasks[i].elapsedTime = 0;
        }
        //At the end of each iteration, the elapsed time for the task is set to the current timer period or 100ms.
        tasks[i].elapsedTime += timerPeriod;
    }
    TimerFlag = 1;
}

void initTimer(void)
{
    Timer_Params params;

    //Init the driver
    Timer_init();

    //Configure the driver
    Timer_Params_init(&params);
    params.period = 100000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    //Open the driver
    timer0 = Timer_open(CONFIG_TIMER_0, &params);
    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        /* Failed to start timer */
        while (1) {}
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{

    //If the button 0 is pressed, then the value of this variable is changed to 1. The value gets set back to 0 at the end of every callback to the TickFct_Btn function
    //When the button is pressed, the value of setpoint is decreased
    button_0 = 1;

}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{

    //If the button 1 is pressed, then the value of this variable is changed to 1. The value gets set back to 0 at the end of every callback to the TickFct_Btn function
    //When the button is pressed, the value of setpoint is increased
    button_1 = 1;

}

//States needed to run the TLED tick function.
//TLED_Init is the initial state for the SM, where it moves directly to the TLED_On_Off state
//TLED_On_Off is the state where two checks are made to see if the temperature is greater than or less than the current set point temp value. Changes to the LED and heat value are made accordingly in this state.
enum TLED_States {TLED_Init, TLED_On_Off};

//Start of the TLED State Machine tick function
int TickFct_TempLED(int state) {

    //Start of the Transition switch, which will move things in between states
    switch (state) {

        //Init state for the tick function. Starting state of the SM
        case TLED_Init:
            //Moves state for task to TLED_On_Off
            state = TLED_On_Off;
            break;

        //Main state of the tick function
        case TLED_On_Off:
            //Moves state for task to TLED_On_Off just in case
            state = TLED_On_Off;
            break;

        default:
            //default state is set to the Init state for the SM
            state = TLED_Init;
            break;

    }

    //Start of the Action switch, which usually contains most of the actions involved with each state.
    switch (state){

        //Init state has no actions
        case TLED_Init:
            break;

        //Main state of the tick function
        case TLED_On_Off:
            //If the temperature is currently less than the set point temp, then the LED is turned on and the heat value is set to 1.
            if (temperature < setpoint) {
                heat = 1;
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            }
            //if the temperature is currently greater than the set point temp, then the LED is turned off and the heat value is set to 0.
            if (temperature > setpoint) {
                heat = 0;
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            }
            break;

        default:
            break;
    }

    //Returns the current state of the SM, which will be used by the task scheduler
    return state;

}

//States needed to run the Btn tick function.
//Btn_Init is the initial state for the SM, where it moves directly to the Btn_Check state
//Btn_Check is the state where a check is made to see if the button_0 and button_1 buttons have been pressed. If they have been pressed, the set point temp variable changes accordingly
enum Btn_States {Btn_Init, Btn_Check};

//Start of the Btn State Machine tick function
int TickFct_Btn(int state){

    //Start of the Transition switch, which will move things in between states
    switch (state) {

       //Init state for the tick function. Starting state of the SM
       case Btn_Init:
           //Moves state for task to Btn_Check
           state = Btn_Check;
           break;

       //Main state of the tick function
       case Btn_Check:
           //Reassigns state for task to Btn_Check just in case
           state = Btn_Check;
           break;

       default:
           //default state is set to the Init state for the SM
           state = Btn_Init;
           break;

    }

    //Start of the Action switch, which usually contains most of the actions involved with each state.
    switch (state) {

       //Init state has no actions
       case Btn_Init:
           break;

       //Main state of the tick function
       case Btn_Check:
           //If button0 has been pressed, then the setpoint is decreased by 1.
           //The if statement checks to see if the button interrupt for button0 has caused the button_0 value to change to 1
           if (button_0 > 0) {
               setpoint -= 1;
           }
           //If button1 has been pressed, then the setpoint is increased by 1.
           //The if statement checks to see if the button interrupt for button1 has caused the button_1 value to change to 1
           if (button_1 > 0) {
               setpoint += 1;
           }

           //Resets button_0 and button_1 values to 0 since to show the buttons are being pressed once.
           button_0 = 0;
           button_1 = 0;
           break;

       default:
           break;
    }

    //Returns the current state of the SM, which will be used by the task scheduler
    return state;
}

/*
 *  ======== mainThread ========
 */



void *mainThread(void *arg0)
{
    /* Call driver init functions */
    initUART();
    initI2C();
    initTimer();
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);
    //GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn off user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);
    //GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);
    //GPIO_enableInt(CONFIG_GPIO_BUTTON_1);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    //Used as an iterator variable for the tasks array. Helps when setting the values of each task in the tasks array
    unsigned char i = 0;


    tasks[i].state = Btn_Init; //Assigns the first task's state to Btn_Init state/starting state
    tasks[i].period = btnCheckTimer; //Assigns the first task's period to btnCheckTimer or 200
    tasks[i].elapsedTime = tasks[i].period; //Assigns the first task's elapsed time to the period of the task
    tasks[i].TickFct = &TickFct_Btn; //Assigns the first task's tick function to TickFct_Btn state machine

    ++i; //Moves to the next item in the tasks array.

    tasks[i].state = TLED_Init; //Assigns the second task's state to TLED_Init state/starting state
    tasks[i].period = led_tempCheckTimer; //Assigns the second task's period to led_tempCheckTimer or 500
    tasks[i].elapsedTime = tasks[i].period; //Assigns the second task's elapsed time to the period of the task
    tasks[i].TickFct = &TickFct_TempLED; //Assigns the second task's tick function to TickFct_TempLED state machine

    //Sets the current set temp point to the temperature read via readTemp()
    setpoint = readTemp();

    //Infinite timer loop
    while(1) {
        //sets the current temperature to the value returned from readTemp()
        temperature = readTemp();

        while (!TimerFlag) {}
        //Sets the TimerFlag back to 0
        TimerFlag = 0;



        //If the outputCheckTimer is greater than or equal to 1000ms or 1 second, then the info will be displayed in the terminal. The outputCheckTimer starts at 1000, so it auto prints the first time.
        if (outputCheckTimer >= 1000) {
            //Increments the seconds value by to show the time change in the terminal display
            seconds += 1;

            //Displays the current temperature, set point temp, seconds, and heat value in the terminal.
            DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,%04d>\n\r", temperature, setpoint, heat, seconds));

            //The outputCheckTimer gets reset to 0 after 10 of the timerPeriods to show that it prints every 1 second.
            outputCheckTimer = 0;
        }

        //Every 100ms, aka the tick of the Timer, the outputCheckTimer is increased by 100ms
        outputCheckTimer += timerPeriod;

    }
}
